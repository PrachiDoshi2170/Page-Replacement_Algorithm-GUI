package mywork;

import java.awt.EventQueue;

import javax.swing.JFrame;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JScrollPane;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.UIManager;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class lru extends JFrame{

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					lru window = new lru();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public lru() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	int capacity;
	int len=0;
	int[] array;
	int page_fault = 0;
	int[][] process;
	private JTable table_1;
	JLabel lblNewLabel_4;
	private void initialize() {

		frame = new JFrame();
		frame.getContentPane().setBackground(UIManager.getColor("Button.background"));
		frame.setBounds(100, 100, 909, 737);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	
		JScrollPane scrollPane = new JScrollPane();
		
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(UIManager.getColor("Button.background"));
		panel.setLayout(null);
		JButton btnNewButton = new JButton("Implement");
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				capacity = Integer.parseInt(textField.getText());
				System.out.println(capacity);
				String getInput = textField_1.getText();
				int i=0,ct=0;
				String tempstr="";
				ArrayList<Integer> arrl = new ArrayList<>();
				while(i<getInput.length()) {
					if(!Character.isWhitespace(getInput.charAt(i))) {
						tempstr+=getInput.charAt(i);
					}	
					else {
						arrl.add(ct, Integer.parseInt(tempstr));
						ct++;
						tempstr = "";
					}
					if(i == getInput.length()-1)
						arrl.add(ct, Integer.parseInt(tempstr));
					i++;
				}
				System.out.println(arrl);
				len = arrl.size();
				array = new int[len];
				for(i=0;i<len;i++) {
					array[i]=arrl.get(i);
				}
				int[][] process = new int[capacity][len];
				ArrayList<Integer> temp= new ArrayList<>();
				ct = 0;
				int teaverse=0;
				for(i=0;i<len;i++) {
					if(!temp.contains(array[i])) {
						if(temp.size()==capacity) {
							temp.remove(0);
							temp.add(capacity-1, array[i]);
						}
						else {
							temp.add(ct, array[i]);
						}
						page_fault++;
						ct++;
					}
					else {
						temp.remove((Object)array[i]);
						temp.add(temp.size(), array[i]);
					}
					for(int j=0;j< capacity;j++) {
						if(temp.size()<capacity) {
							if(j==temp.size())
								break;
						}
						process[j][i] = temp.get(j);
					}
				}
				lblNewLabel_4.setText(String.valueOf(page_fault));
				String[][] processstr = new String[capacity][len];
				String[] arraystr = new String[len];
				for(int j=0;j< capacity;j++) {
					for(i=0;i<len;i++) {
						processstr[j][i] = String.valueOf(process[j][i]);
					}
				}
				for(i=0;i<len;i++) {
					arraystr[i] = String.valueOf(array[i]);
				}
				table_1 = new JTable(processstr,arraystr);
				int width = 50*len;
				int height = 50*capacity;
				table_1.setRowHeight(50-(25/capacity));
				scrollPane.setBounds(300, 400, width, height);
				//table_1.setBounds(50, 397, width, height);
				scrollPane.setViewportView(table_1);
			}
			
		});
		btnNewButton.setBounds(356, 230, 198, 37);
		panel.add(btnNewButton);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
		
		JLabel lblNewLabel_2 = new JLabel("Least Recently Used");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(238, 5, 400, 37);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		
		JLabel lblNewLabel = new JLabel("No. of frames:");
		lblNewLabel.setBounds(187, 108, 178, 29);
		panel.add(lblNewLabel);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setFont(new Font("Century Schoolbook", Font.BOLD, 22));
		
		textField = new JTextField();
		textField.setBounds(409, 106, 96, 30);
		panel.add(textField);
		textField.setToolTipText("This text field take the input for the no of the frame that are available to contain the pages. This no. will be converted into number of row.\r\n");
		textField.setFont(new Font("Tahoma", Font.PLAIN, 24));
		textField.setColumns(1);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Century Schoolbook", Font.BOLD, 16));
		textField_1.setBounds(405, 161, 269, 30);
		panel.add(textField_1);
		textField_1.setColumns(1);
		
		JLabel lblNewLabel_3 = new JLabel("Total Page Faults: ");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel_3.setBounds(59, 292, 285, 29);
		panel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("0");
		lblNewLabel_4.setForeground(UIManager.getColor("Button.foreground"));
		lblNewLabel_4.setBackground(UIManager.getColor("Button.focus"));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel_4.setBounds(356, 292, 198, 29);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_1 = new JLabel("Input your windows:");
		lblNewLabel_1.setBounds(145, 159, 250, 29);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Century Schoolbook", Font.BOLD, 22));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(19, 40, 60));
		panel_1.setAlignmentY(0.0f);
		panel_1.setAlignmentX(0.0f);
		
		JLabel label = new JLabel();
		label.setIcon(new ImageIcon(lru.class.getResource("/images/simulator.png")));
		label.setForeground(UIManager.getColor("Button.highlight"));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel label_1 = new JLabel();
		label_1.setIcon(new ImageIcon(lru.class.getResource("/images/algorithm.png")));
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Algo go1 = new Algo();
				go1.setVisible(true);
			}
		});
		
		JLabel label_2 = new JLabel();
		label_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				homepage go = new homepage();
				go.setVisible(true);
			}
		});
		label_2.setIcon(new ImageIcon(lru.class.getResource("/images/home.png")));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(label_1, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
						.addComponent(label, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(106)
					.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
					.addGap(34)
					.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
					.addGap(46)
					.addComponent(label, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(500, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 0, GroupLayout.PREFERRED_SIZE)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(93)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 802, GroupLayout.PREFERRED_SIZE))
				.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 0, GroupLayout.PREFERRED_SIZE)
				.addComponent(panel, GroupLayout.PREFERRED_SIZE, 331, GroupLayout.PREFERRED_SIZE)
				.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
		);
		frame.getContentPane().setLayout(groupLayout);
		
		
		
	}
}